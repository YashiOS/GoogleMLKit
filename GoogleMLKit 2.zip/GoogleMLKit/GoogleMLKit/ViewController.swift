//
//  ViewController.swift
//  GoogleMLKit
//
//  Created by Yash Saxena on 29/03/23.
//

import UIKit
import MLKit
import MLKitDigitalInkRecognition



class ViewController: UIViewController {
    let ink: Ink? = nil
    var recognizer: DigitalInkRecognizer? = nil
    var preContext: String = ""
    var writingArea = WritingArea.init(width: 393, height: 852)

    var location: String = ""
    var timeStamp: String = ""
    var kMillisecondsPerTimeInterval = 1000.0
    var lastPoint = CGPoint.zero
    private var strokes: [Stroke] = []
    private var points: [StrokePoint] = []
    
    
    
    @IBOutlet weak var mainImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let languageTag = "en-US"
         let identifier = DigitalInkRecognitionModelIdentifier(forLanguageTag: languageTag)
         if identifier == nil {
          print("Identifier null")
         }
        let model = DigitalInkRecognitionModel.init(modelIdentifier: identifier!)
         let modelManager = ModelManager.modelManager()
         let conditions = ModelDownloadConditions.init(allowsCellularAccess: true,
                                                allowsBackgroundDownloading: true)
         modelManager.download(model, conditions: conditions)
        let options: DigitalInkRecognizerOptions = DigitalInkRecognizerOptions.init(model: model)
         recognizer = DigitalInkRecognizer.digitalInkRecognizer(options: options)
      
    }
    
    func checkDownloaded() {
        let model : DigitalInkRecognitionModel? = nil
        let modelManager = ModelManager.modelManager()
        modelManager.isModelDownloaded(model!)
    }
    
    
    func checkDeletedCode() {
        let model : DigitalInkRecognitionModel? = nil
        let modelManager = ModelManager.modelManager()
        if modelManager.isModelDownloaded(model!) {
            modelManager.deleteDownloadedModel(
                model!,
               completion: {
                 error in
                 if error != nil {
                   print("Error in Model Manager ")
                   return
                 }
                print("Error in checkDeletedCode")
               })
        }
        
    }
    func drawLine(from fromPoint: CGPoint, to toPoint: CGPoint) {
      UIGraphicsBeginImageContext(view.frame.size)
      guard let context = UIGraphicsGetCurrentContext() else {
        return
      }
      mainImageView.image?.draw(in: view.bounds)
      context.move(to: fromPoint)
      context.addLine(to: toPoint)
      context.setLineCap(.round)
      context.setBlendMode(.normal)
      context.setLineWidth(10.0)
      context.setStrokeColor(UIColor.white.cgColor)
      context.strokePath()
      mainImageView.image = UIGraphicsGetImageFromCurrentImageContext()
      mainImageView.alpha = 1.0
      UIGraphicsEndImageContext()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
        return
      }
      lastPoint = touch.location(in: mainImageView)
      let t = touch.timestamp
      points = [StrokePoint.init(x: Float(lastPoint.x),
                                 y: Float(lastPoint.y),
                                 t: Int(t * kMillisecondsPerTimeInterval))]
      drawLine(from:lastPoint, to:lastPoint)
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
      guard let touch = touches.first else {
        return
      }
      let currentPoint = touch.location(in: mainImageView)
      let t = touch.timestamp
      points.append(StrokePoint.init(x: Float(currentPoint.x),
                                     y: Float(currentPoint.y),
                                     t: Int(t * kMillisecondsPerTimeInterval)))
      drawLine(from: lastPoint, to: currentPoint)
      lastPoint = currentPoint
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
      guard let touch = touches.first else {
        return
      }
      let currentPoint = touch.location(in: mainImageView)
      let t = touch.timestamp
      points.append(StrokePoint.init(x: Float(currentPoint.x),
                                     y: Float(currentPoint.y),
                                     t: Int(t * kMillisecondsPerTimeInterval)))
      drawLine(from: lastPoint, to: currentPoint)
      lastPoint = currentPoint
      strokes.append(Stroke.init(points: points))
      self.points = []
        
      doRecognition()
    }
    
    func doRecognition() {
      let ink = Ink.init(strokes: strokes)
        recognizer!.recognize(
        ink: ink,
        completion: {
          [unowned self]
          (result: DigitalInkRecognitionResult?, error: Error?) in
          var alertTitle = ""
          var alertText = ""
          if let result = result, let candidate = result.candidates.first {
            alertTitle = "I recognized this:"
            alertText = candidate.text
          } else {
            alertTitle = "I hit an error:"
            alertText = error!.localizedDescription
          }
          let alert = UIAlertController(title: alertTitle,
                                      message: alertText,
                               preferredStyle: UIAlertController.Style.alert)
          alert.addAction(UIAlertAction(title: "OK",
                                        style: UIAlertAction.Style.default,
                                      handler: nil))
          self.present(alert, animated: true, completion: nil)
        }
      )
    }
    
    
}







